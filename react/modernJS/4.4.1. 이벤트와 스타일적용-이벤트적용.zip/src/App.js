export const App = () => {
  const onClickButton = () => {
    alert("test of react onClickButton");
  };

  return (
    <>
      {console.log("TEST")}
      <h1>안녕하세요!</h1>
      <p>잘 지내시죠?</p>
      <button onClick={onClickButton}>버튼</button>
    </>
  );
};
