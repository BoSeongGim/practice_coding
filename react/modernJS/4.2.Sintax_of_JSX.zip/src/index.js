//4.2. JSX표기법
//ReactDom import (99page)
import { Fragment } from "react";
import ReactDOM from "react-dom";

//함수 정의(99page)
const App = () => {
  /*2개 이상의 값을 리턴하려면 
    [방법1]<div>안에 작성하여 <div>를 통째로 리턴한다.
    [방법2]<Fragment>안에 작성하여 <Fragment>를 통째로 리턴한다.
    [방법3]빈태그(<>)안에 작성하여 <>를 통째로 리턴한다.
  */

  /* 
  //[방법1]<div>안에 작성하여 <div>를 통째로 리턴한다.
  return(
    <div>
      <h1>div로 모아서 return한 예제입니다.</h1>
      <h1>안녕하세요!</h1>
      <p>잘 지내시죠?</p>
    </div>
    );
  */
  /*
  //[방법2]<Fragment>안에 작성하여 <Fragment>를 통째로 리턴한다.
  return (
    <Fragment>
      <h1>Fragment로 모아서 return한 예제입니다.</h1>
      <h1>안녕하세요!</h1>
      <p>잘 지내시죠?</p>
    </Fragment>
  );
  */

  //[방법3]빈태그(<>)안에 작성하여 <>를 통째로 리턴한다.
  return (
    <>
      <h1>빈태그로 모아서 리턴한 예제입니다.</h1>
      <h1>안녕하세요!</h1>
      <p>dddd</p>
    </>
  );
};

//인수지정(100page)
ReactDOM.render(<App />, document.getElementById("root"));
//ReactDOM.render(랜더대상, 컴포넌트);
