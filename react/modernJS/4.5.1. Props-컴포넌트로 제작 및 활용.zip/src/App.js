import { ColoredMessage } from "./components/ColoredMessage";
export const App = () => {
  const onClickButton = () => {
    alert("test of react onClickButton");
  };

  const contentPinkStyle = {
    color: "pink",
    fontSize: "20px"
  };

  return (
    <>
      {console.log("TEST")}
      <h1 style={{ color: "red" }}>안녕하세요!</h1>
      <ColoredMessage />
      <p style={contentPinkStyle}>잘 지냅니다!</p>
      <button onClick={onClickButton}>버튼</button>
    </>
  );
};
