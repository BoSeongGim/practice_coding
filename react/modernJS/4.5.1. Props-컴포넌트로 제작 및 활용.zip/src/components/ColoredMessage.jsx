export const ColoredMessage = () => {
  const contentStyle = {
    color: "blue",
    fontsize: "20px"
  };

  return <p style={contentStyle}> 잘 지내시죠? -from ColoredMessage </p>;
};
