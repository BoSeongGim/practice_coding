//export : 함수 컴포넌트를 다른 파일에서도 사용할 수 있도록 한다.
export const App = () => {
  return (
    <>
      <h1>안녕하세요!</h1>
      <p>잘 지내시죠?</p>
    </>
  );
};
