import { ColoredMessage } from "./components/ColoredMessage";

export const App = () => {
  const onClickButton = () => {
    alert("test of react onClickButton");
  };

  return (
    <>
      <h1 style={{ color: "red" }}>안녕하세요!</h1>
      <ColoredMessage
        color="blue"
        message="잘 지내시죠? color와 message를 Props로 전달"
      />
      <ColoredMessage color="green" message="잘 지냅니다!22" />
      <button onClick={onClickButton}>버튼</button>
    </>
  );
};
