export const ColoredMessage = (props) => {
  console.log(props);

  // {color="blue", message="잘 지내시죠? color와 message를 Props로 전달"}
  const contentStyle = {
    color: props.color,
    fontsize: "20px"
  };

  return <p style={contentStyle}>{props.message}</p>;
};
