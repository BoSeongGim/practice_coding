export const App = () => {
  const onClickButton = () => {
    alert("test of react alert");
  };

  //CSS 객체
  const contentStyle = {
    color: "blue",
    fontSize: "40px"
  };

  return (
    <>
      <h1 style={{ color: "red" }}>Hello</h1>
      <p style={contentStyle}>have a nice day!</p>
      <button onClick={onClickButton}>button</button>
    </>
  );
};
